import smtplib
from email.message import EmailMessage


def send_interview_email(
    candidate_name,
    candidate_email,
    job_role,
    interview_date,
    interview_time,
    meeting_link
):

    # உங்கள் Gmail
    EMAIL = "vaishuprojecr@gmail.com"

    # Gmail App Password
    PASSWORD = "ggpn lmfq dlbn zcte"

    msg = EmailMessage()

    msg["Subject"] = "Interview Invitation"

    msg["From"] = EMAIL

    msg["To"] = candidate_email

    body = f"""
Dear {candidate_name},

Congratulations!

Your profile has been shortlisted for the next round.

Interview Details

Job Role : {job_role}

Interview Date : {interview_date}

Interview Time : {interview_time}

Meeting Link :
{meeting_link}

Please join the meeting 10 minutes before the scheduled time.

Best Regards,

HR Team
"""

    msg.set_content(body)

    try:

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:

            smtp.login(EMAIL, PASSWORD)

            smtp.send_message(msg)

        return True

    except Exception as e:

       print("===================================")
       print("EMAIL ERROR")
       print(type(e).__name__)
       print(e)
       print("===================================")

       return False