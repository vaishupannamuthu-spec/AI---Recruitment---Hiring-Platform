from skill_extractor import extract_skills

skills = extract_skills(
    "../resumes/Durga_profile_old.pdf"
)

print(skills)