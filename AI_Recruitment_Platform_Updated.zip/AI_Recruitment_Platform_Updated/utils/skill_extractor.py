import pdfplumber

def extract_skills(pdf_path):

    skills_database = [
        "python",
        "java",
        "sql",
        "mysql",
        "react",
        "reactjs",
        "javascript",
        "html",
        "css",
        "php",
        "laravel",
        "git",
        "github",
        "c",
        "c++",
        "machine learning",
        "data science",
        "streamlit"
    ]

    text = ""

    with pdfplumber.open(pdf_path) as pdf:

        for page in pdf.pages:

            page_text = page.extract_text()

            if page_text:
                text += page_text.lower()

    found_skills = []

    for skill in skills_database:

        if skill.lower() in text:
            found_skills.append(skill)

    print("Detected Skills:", found_skills)

    return found_skills