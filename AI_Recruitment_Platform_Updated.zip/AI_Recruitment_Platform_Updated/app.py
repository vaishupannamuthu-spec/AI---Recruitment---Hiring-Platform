import streamlit as st

st.set_page_config(
    page_title="AI Recruitment & Hiring Platform",
    page_icon="🤖"
)
import streamlit as st


st.title("🤖 AI Recruitment & Hiring Platform")

st.subheader(
    "Smart Resume Screening & Candidate Management System"
)

st.write(
    "Welcome to the AI Recruitment & Hiring Platform."
)

st.success("Ready to Use 🚀")

