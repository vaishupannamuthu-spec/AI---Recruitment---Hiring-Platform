import sqlite3

conn = sqlite3.connect("recruitment.db")
cursor = conn.cursor()

columns = [
    ("candidate_email", "TEXT"),
    ("job_role", "TEXT"),
    ("meeting_link", "TEXT"),
    ("interviewer", "TEXT")
]

for column, datatype in columns:
    try:
        cursor.execute(
            f"ALTER TABLE interviews ADD COLUMN {column} {datatype}"
        )
        print(f"{column} added successfully.")
    except sqlite3.OperationalError:
        print(f"{column} already exists.")

conn.commit()
conn.close()

print("Interview table updated successfully.")