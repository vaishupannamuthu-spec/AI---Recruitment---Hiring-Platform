import sqlite3

conn = sqlite3.connect("recruitment.db")
cur = conn.cursor()

cur.execute("PRAGMA table_info(candidates)")
print(cur.fetchall())

conn.close()