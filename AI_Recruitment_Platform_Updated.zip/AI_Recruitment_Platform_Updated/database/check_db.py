import streamlit as st
import sqlite3
import pandas as pd

conn = sqlite3.connect("recruitment.db")

df = pd.read_sql_query(
    "SELECT * FROM candidates",
    conn
)

st.dataframe(df)

conn.close()