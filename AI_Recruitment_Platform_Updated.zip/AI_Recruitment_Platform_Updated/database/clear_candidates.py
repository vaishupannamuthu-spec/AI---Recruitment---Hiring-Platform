import sqlite3

conn = sqlite3.connect("recruitment.db")
cur = conn.cursor()

cur.execute("DELETE FROM candidates")

conn.commit()
conn.close()

print("All records deleted")