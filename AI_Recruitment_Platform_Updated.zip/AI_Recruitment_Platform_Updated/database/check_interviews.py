import sqlite3

conn = sqlite3.connect("recruitment.db")
cursor = conn.cursor()

cursor.execute("PRAGMA table_info(interviews)")

rows = cursor.fetchall()

if rows:
    print("Interview Table Columns:\n")
    for row in rows:
        print(row)
else:
    print("interviews table not found!")

conn.close()