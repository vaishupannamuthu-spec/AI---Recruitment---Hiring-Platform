import sqlite3

conn = sqlite3.connect("recruitment.db")
cur = conn.cursor()
cur.execute("PRAGMA table_info(candidates)")
print(cur.fetchall())

# Candidates Table
cur.execute("""
CREATE TABLE IF NOT EXISTS candidates(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    phone TEXT,
    skills TEXT,
    resume TEXT
)
""")

# Users Table
cur.execute("""
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT,
    role TEXT
)
""")

# Jobs Table
cur.execute("""
CREATE TABLE IF NOT EXISTS jobs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_role TEXT,
    skills TEXT,
    experience INTEGER,
    salary TEXT
)
""")

# Interviews Table
cur.execute("""
CREATE TABLE IF NOT EXISTS interviews(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_name TEXT,
    date TEXT,
    time TEXT,
    status TEXT
)
""")

conn.commit()
conn.close()

print("All Tables Created Successfully")