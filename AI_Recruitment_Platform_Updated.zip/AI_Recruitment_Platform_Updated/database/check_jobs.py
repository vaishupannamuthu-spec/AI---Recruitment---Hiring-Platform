import sqlite3

conn = sqlite3.connect("recruitment.db")

cursor = conn.cursor()

cursor.execute("SELECT * FROM jobs")

for row in cursor.fetchall():
    print(row)

conn.close()