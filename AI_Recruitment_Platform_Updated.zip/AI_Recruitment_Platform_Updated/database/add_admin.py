import sqlite3

conn = sqlite3.connect("recruitment.db")

cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT,
password TEXT,
role TEXT
)
""")

cursor.execute("""
INSERT INTO users(username,password,role)
VALUES(?,?,?)
""",
("admin","admin123","Admin"))

conn.commit()
conn.close()

print("Admin Added Successfully")