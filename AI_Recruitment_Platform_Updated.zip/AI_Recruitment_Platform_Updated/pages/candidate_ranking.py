import streamlit as st
import sqlite3
import pandas as pd

st.title("Candidate Ranking System")

conn = sqlite3.connect("database/recruitment.db")

df = pd.read_sql_query("""
SELECT
    name,
    email,
    phone,
    skills
FROM candidates
""", conn)
df = df.drop_duplicates(
    subset=["name"]
)


conn.close()

scores = []

for skill in df["skills"]:

    if pd.notna(skill) and skill != "":
        score = len(skill.split(",")) * 10
    else:
        score = 0

    scores.append(score)

df["Score"] = scores

df = df.sort_values(
    by="Score",
    ascending=False
)

df.reset_index(
    drop=True,
    inplace=True
)

df["Rank"] = range(
    1,
    len(df) + 1
)

st.dataframe(
    df[[
        "name",
        "email",
        "phone",
        "skills",
        "Score",
        "Rank"
    ]]
)