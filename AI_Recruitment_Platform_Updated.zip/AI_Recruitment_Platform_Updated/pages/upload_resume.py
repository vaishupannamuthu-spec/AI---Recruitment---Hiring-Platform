import streamlit as st
import sys
import os

sys.path.append(os.path.dirname(__file__))
from utils.skill_extractor import extract_skills
import sqlite3
import os
import sys
from utils.skill_extractor import extract_skills

st.title("Candidate Resume Upload")

name = st.text_input("Enter Name")
email = st.text_input("Enter Email")
phone = st.text_input("Enter Phone Number")

uploaded_file = st.file_uploader(
    "Upload Resume",
    type=["pdf"]
)

if st.button("Submit"):

    if uploaded_file:

        try:

            # Create Resume Folder
            os.makedirs("resumes", exist_ok=True)

            file_path = os.path.join(
                "resumes",
                uploaded_file.name
            )

            # Save PDF
            with open(file_path, "wb") as f:
                f.write(uploaded_file.read())

            # Extract Skills
            skills = extract_skills(file_path)

            skills_text = ", ".join(skills)

            print("Extracted Skills:", skills_text)

            # Database Connection
            conn = sqlite3.connect(
                "database/recruitment.db"
            )

            cursor = conn.cursor()
            skills_text = ", ".join(skills)
            print(name)
            print(email)
            print(phone) 
            st.write("Name =", repr(name))
            st.write("Email =", repr(email))
            st.write("Phone =", repr(phone))
            cursor.execute("""
                                                          
            INSERT INTO candidates
            (
                name,
                email,
                phone,
                skills,
                resume
            )
            VALUES (?,?,?,?,?)
            """,
            (
                name,
                email,
                phone,
                skills_text,
                uploaded_file.name
            ))

            conn.commit()
            conn.close()

            st.success(
                "Candidate Saved Successfully"
            )

            st.write("Detected Skills:")
            st.write(skills)

        except Exception as e:

            st.error(
                f"Error: {str(e)}"
            )

    else:

        st.error(
            "Please Upload Resume"
        )