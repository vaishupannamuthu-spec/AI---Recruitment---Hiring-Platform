import streamlit as st
import sqlite3
import pandas as pd

from utils.send_email import send_interview_email

st.title("Interview Scheduler")

conn = sqlite3.connect("database/recruitment.db")

# Load Candidate Details
candidates = pd.read_sql_query(
    """
    SELECT name, email
    FROM candidates
    """,
    conn
)

if candidates.empty:

    st.warning("No Candidates Found")

else:

    candidate = st.selectbox(
        "Select Candidate",
        candidates["name"].tolist()
    )

    candidate_email = candidates.loc[
        candidates["name"] == candidate,
        "email"
    ].values[0]

    st.info(f"Candidate Email : {candidate_email}")

    job_role = st.text_input("Job Role")

    interview_date = st.date_input("Interview Date")

    interview_time = st.time_input("Interview Time")

    meeting_link = st.text_input("Google Meet Link")

    interviewer = st.text_input("Interviewer Name")

    if st.button("Schedule Interview"):

        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO interviews
        (
            candidate_name,
            date,
            time,
            status,
            candidate_email,
            job_role,
            meeting_link,
            interviewer
        )
        VALUES (?,?,?,?,?,?,?,?)
        """,
        (
            candidate,
            str(interview_date),
            str(interview_time),
            "Scheduled",
            candidate_email,
            job_role,
            meeting_link,
            interviewer
        ))

        conn.commit()

        mail_sent = send_interview_email(
            candidate_name=candidate,
            candidate_email=candidate_email,
            job_role=job_role,
            interview_date=str(interview_date),
            interview_time=str(interview_time),
            meeting_link=meeting_link
        )

        if mail_sent:
            st.success("Interview Scheduled & Email Sent Successfully ✅")
        else:
            st.warning("Interview Scheduled but Email Sending Failed.")

conn.close()