import streamlit as st
import sqlite3
import pandas as pd

st.title("Candidate Dashboard")

conn = sqlite3.connect(
    "database/recruitment.db"
)

# Candidate Details
candidates = pd.read_sql_query(
    "SELECT * FROM candidates",
    conn
)

candidates = candidates.drop_duplicates(
    subset=["name"]
)

st.subheader("Candidate Details")
st.dataframe(candidates)

# Status Details
status_df = pd.read_sql_query(
    """
    SELECT candidate_name,status
    FROM interviews
    """,
    conn
)

status_df = status_df.drop_duplicates(
    subset=["candidate_name"]
)

st.subheader("Interview Status")
st.dataframe(status_df)

conn.close()