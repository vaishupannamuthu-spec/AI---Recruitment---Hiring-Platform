import streamlit as st
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt

st.title("Analytics Dashboard")

# Database Connection
conn = sqlite3.connect(
    "database/recruitment.db"
)

# Candidate Data
df = pd.read_sql_query(
    """
    SELECT
        name,
        email,
        phone,
        skills
    FROM candidates
    """,
    conn
)

conn.close()

# Remove Duplicate Candidates
df = df.drop_duplicates(
    subset=["name"]
)

# ==========================
# Candidate Score Calculation
# ==========================

scores = []

for skill in df["skills"]:

    if pd.notna(skill) and skill != "":

        score = len(
            skill.split(",")
        ) * 10

    else:

        score = 0

    scores.append(score)

df["Score"] = scores

# ==========================
# Candidate Ranking Chart
# ==========================

st.subheader(
    "Candidate Ranking Analysis"
)

fig, ax = plt.subplots()

ax.bar(
    df["name"],
    df["Score"]
)

ax.set_title(
    "Candidate Ranking"
)

ax.set_xlabel(
    "Candidate Name"
)

ax.set_ylabel(
    "Score"
)

st.pyplot(fig)

# ==========================
# Top Skills Chart
# ==========================

all_skills = []

for skills in df["skills"]:

    if pd.notna(skills):

        all_skills.extend(
            [
                s.strip()
                for s in skills.split(",")
            ]
        )

skill_count = pd.Series(
    all_skills
).value_counts()

st.subheader(
    "Top Skills Analysis"
)

fig2, ax2 = plt.subplots()

skill_count.plot(
    kind="bar",
    ax=ax2
)

ax2.set_title(
    "Top Skills"
)

ax2.set_xlabel(
    "Skills"
)

ax2.set_ylabel(
    "Count"
)

st.pyplot(fig2)

# ==========================
# Individual Candidate Analysis
# ==========================

st.subheader(
    "Individual Candidate Analysis"
)

for index, row in df.iterrows():

    st.write(
        f"### Candidate : {row['name']}"
    )

    fig3, ax3 = plt.subplots()

    ax3.bar(
        [row["name"]],
        [row["Score"]]
    )

    ax3.set_ylim(
        0,
        100
    )

    ax3.set_title(
        f"{row['name']} Score"
    )

    ax3.set_ylabel(
        "Score"
    )

    st.pyplot(fig3)

    st.write(
        "Email :",
        row["email"]
    )

    st.write(
        "Phone :",
        row["phone"]
    )

    st.write(
        "Skills :",
        row["skills"]
    )

    st.write(
        "Score :",
        row["Score"]
    )

    st.markdown("---")