import streamlit as st
import sqlite3

st.title("Job Posting")

job_role = st.text_input("Job Role")

skills = st.text_area(
    "Required Skills (comma separated)"
)

experience = st.number_input(
    "Experience (Years)",
    min_value=0
)

salary = st.text_input("Salary")

if st.button("Add Job"):

    conn = sqlite3.connect(
        "database/recruitment.db"
    )

    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO jobs
    (
        job_role,
        skills,
        experience,
        salary
    )
    VALUES (?,?,?,?)
    """,
    (
        job_role,
        skills,
        experience,
        salary
    ))

    conn.commit()
    conn.close()

    st.success(
        "Job Added Successfully"
    )