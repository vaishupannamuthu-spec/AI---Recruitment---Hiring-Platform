import streamlit as st
import sqlite3
import pandas as pd

st.title("Candidate Status Update")

conn = sqlite3.connect(
    "database/recruitment.db"
)

df = pd.read_sql_query(
    "SELECT * FROM interviews",
    conn
)

if not df.empty:

    candidate = st.selectbox(
    "Select Candidate",
    df["candidate_name"].unique()
)

    status = st.selectbox(
        "Select Status",
        [
            "Pending",
            "Shortlisted",
            "Selected",
            "Rejected"
        ]
    )

    if st.button("Update Status"):

        cursor = conn.cursor()

        cursor.execute("""
        UPDATE interviews
        SET status=?
        WHERE candidate_name=?
        """,
        (
            status,
            candidate
        ))

        conn.commit()

        st.success(
            "Status Updated Successfully"
        )

conn.close()