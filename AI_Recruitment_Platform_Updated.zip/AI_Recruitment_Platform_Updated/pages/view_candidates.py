import streamlit as st
import sqlite3
import pandas as pd

st.title("View Candidates")

conn = sqlite3.connect(
    "database/recruitment.db"
)

df = pd.read_sql_query(
    """
    SELECT
    name,
    email,
    phone,
    skills
    FROM candidates
    """,
    conn
)

conn.close()

st.dataframe(df)