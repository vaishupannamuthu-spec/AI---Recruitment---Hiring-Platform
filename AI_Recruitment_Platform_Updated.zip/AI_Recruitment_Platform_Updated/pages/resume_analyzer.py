import streamlit as st
import sqlite3
import pandas as pd

st.title("AI Resume Analyzer")

# Database Connection
conn = sqlite3.connect(
    "database/recruitment.db"
)

# Load Candidates
candidates = pd.read_sql_query(
    "SELECT * FROM candidates",
    conn
)

# Load Jobs
jobs = pd.read_sql_query(
    "SELECT * FROM jobs",
    conn
)

conn.close()

# Validation
if candidates.empty:
    st.warning("No Candidates Found")

elif jobs.empty:
    st.warning("No Jobs Found")

else:

    candidate_name = st.selectbox(
        "Select Candidate",
        candidates["name"]
    )

    selected_job = st.selectbox(
        "Select Job",
        jobs["job_role"]
    )

    candidate = candidates[
        candidates["name"] == candidate_name
    ].iloc[0]

    job = jobs[
        jobs["job_role"] == selected_job
    ].iloc[0]

    # Candidate Skills
    candidate_skills = set(
        skill.strip().lower()
        for skill in str(
            candidate["skills"]
        ).replace("\n", ",").split(",")
        if skill.strip()
    )

    # Job Skills
    job_skills = set(
        skill.strip().lower()
        for skill in str(
            job["skills"]
        ).replace("\n", ",").split(",")
        if skill.strip()
    )

    # Matched Skills
    matched_skills = (
        candidate_skills
        &
        job_skills
    )

    # Missing Skills
    missing_skills = (
        job_skills
        -
        candidate_skills
    )

    # Score
    if len(job_skills) > 0:

        score = (
            len(matched_skills)
            /
            len(job_skills)
        ) * 100

    else:

        score = 0

    st.subheader("Resume Analysis")

    st.metric(
        "Resume Score",
        f"{round(score,2)}%"
    )

    st.write(
        "Matched Skills:"
    )

    st.success(
        ", ".join(matched_skills)
    )

    st.write(
        "Missing Skills:"
    )

    if missing_skills:

        st.error(
            ", ".join(missing_skills)
        )

    else:

        st.success(
            "No Missing Skills"
        )

    st.write(
        "Recommendation:"
    )

    if score >= 80:

        st.success(
            "Excellent Match. Ready For Interview."
        )

    elif score >= 60:

        st.warning(
            "Good Match. Improve Missing Skills."
        )

    else:

        st.error(
            "Needs More Skill Development."
        )