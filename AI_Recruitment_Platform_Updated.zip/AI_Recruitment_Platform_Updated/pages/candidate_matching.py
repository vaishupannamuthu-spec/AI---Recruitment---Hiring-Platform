import streamlit as st
import sqlite3
import pandas as pd

st.title("Candidate Matching System")

# Database Connection
conn = sqlite3.connect(
    "database/recruitment.db"
)

# Load Candidates
candidates = pd.read_sql_query(
    "SELECT * FROM candidates",
    conn
)
candidates = candidates.drop_duplicates(
    subset=["name"]
)
# Load Jobs
jobs = pd.read_sql_query(
    "SELECT * FROM jobs",
    conn
)

conn.close()

# Check Data Available
if candidates.empty:
    st.warning("No Candidates Found")
elif jobs.empty:
    st.warning("No Jobs Found")
else:

    for _, candidate in candidates.iterrows():

        st.subheader(
            f"Candidate : {candidate['name']}"
        )

        # Candidate Skills
        #st.write("candidate skills:",candidate["skills"])
        candidate_skills = set(
    skill.strip().lower()
    for skill in str(candidate["skills"])
        .replace("\n", ",")
        .split(",")
    if skill.strip()
)

        results = []

        for _, job in jobs.iterrows():

            # Job Skills
            job_skills = set(
    skill.strip().lower()
    for skill in str(job["skills"])
        .replace("\n", ",")
        .split(",")
    if skill.strip()
)
            # Matched Skills
            #st.write("Candidate Skills Set:", candidate_skills)
             #st.write("Job Skills Set:", job_skills) 
            
            matched = (
                candidate_skills
                &
                job_skills
            )
            #st.write("matched:",matched)

            # Match Percentage
            if len(job_skills) > 0:

                score = (
                    len(matched)
                    /
                    len(job_skills)
                ) * 100

            else:

                score = 0

            results.append(
                {
                    "Job Role":
                    job["job_role"],

                    "Required Skills":
                    ", ".join(job_skills),

                    "Matched Skills":
                    ", ".join(matched),

                    "Match %":
                    round(score, 2)
                }
            )

        st.dataframe(results)

        st.markdown("---")