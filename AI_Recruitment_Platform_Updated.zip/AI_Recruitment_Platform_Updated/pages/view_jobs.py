import streamlit as st
import sqlite3
import pandas as pd

st.title("Available Jobs")

conn = sqlite3.connect(
    "database/recruitment.db"
)

df = pd.read_sql_query(
    "SELECT * FROM jobs",
    conn
)

conn.close()

st.dataframe(df)