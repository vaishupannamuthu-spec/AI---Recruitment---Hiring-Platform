import streamlit as st
import sqlite3

st.title("Admin Login")

# Database connect
conn = sqlite3.connect("database/recruitment.db")
cursor = conn.cursor()

# Users table create
cursor.execute("""
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT
)
""")

# Default admin create
cursor.execute("""
INSERT OR IGNORE INTO users(username,password)
VALUES('admin','1234')
""")

conn.commit()

# Login Form
username = st.text_input("Username")
password = st.text_input("Password", type="password")

if st.button("Login"):

    cursor.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username, password)
    )

    user = cursor.fetchone()

    if user:
        st.success("✅ Login Successful")
        st.write(f"Welcome {username}")
    else:
        st.error("❌ Invalid Username or Password")

conn.close()